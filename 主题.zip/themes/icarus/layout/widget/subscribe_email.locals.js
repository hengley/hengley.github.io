module.exports = (ctx, locals) => {
    return locals;
}
